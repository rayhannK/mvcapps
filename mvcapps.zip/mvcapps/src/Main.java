//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        for (int i = 0; i < 50; i++) {
            System.out.println("This is the state:" + reset(true));
        }
    }

    public static int reset(boolean randomly) {
        int state = 0;
        if (randomly) {
            //Random stuff = Utilities.rng;
            //how to use the above statement...?

            int randomNum = (int)(Math.random() * ((1) + 1));
            state = randomNum;

        }
        else {
            state = 0;
            //it says in cell class that it's setting state to random or initial value (0)
        }
        return state;
    }
}