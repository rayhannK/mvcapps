package CALab;

import java.awt.*;
import java.util.*;
import java.io.*;
import mvc.*;

public abstract class Cell extends Publisher implements Serializable {

    protected int row = 0, col = 0;
    protected Set<Cell> neighbors = new HashSet<Cell>();
    protected Grid myGrid = null;
    protected Cell partner = null;


    // choose a random neighbor as a partner
    public void choosePartner() {
        if (partner == null && neighbors != null) {
            //set partner to null
            partner = null;

            //convert neighbors set to a local array
            Cell[] neigh = new Cell[neighbors.size()];

            int i = 0;
            for(Cell elements: neighbors){
                neigh[i] = elements;
                i++;
            }

            // Shuffle the array to ensure all neighbors are covered
            Collections.shuffle(Arrays.asList(neigh));

            for(Cell neighbor : neigh) {
                if(neighbor.partner == null) {
                    partner = neighbor;
                    partner.partner = this;
                    break;
                }
            }


            //starting at a random position in the array search for a neighbor without a partner
            //make the first such neighbor (if any) the partner and set its partner field to this
//            Random random = new Random();
//            int ind = random.nextInt(neigh.length);
//            for(int j = ind; ind < neigh.length; ind++){
//                if(neigh[ind].partner == null){
//                    partner = neigh[ind];
//                    partner.partner = this;
//                    break;
//                }
//            }
        }
    }

    public void unpartner() {
        if (partner != null) {
            if (partner.partner != null) {
                partner.partner = null;
            }
            partner = null;
        }
    }

    public abstract int getStatus();
    public abstract Color getColor();


    // observer neighbors' states
    public abstract void observe();
    // interact with a random neighbor
    public abstract void interact();
    // update my state
    public abstract void update();
    // set status to status + 1 mod whatever
    public abstract void nextState();
    // set status to a random or initial value
    public abstract void reset(boolean randomly);

}