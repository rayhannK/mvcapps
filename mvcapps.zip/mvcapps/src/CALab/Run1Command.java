package CALab;
import mvc.*;

public class Run1Command extends Command{
    public Run1Command(Model model){
        super(model);
    }
    public void execute(){
        Grid grid = (Grid)model;
        grid.updateLoop(1);
    }
}
