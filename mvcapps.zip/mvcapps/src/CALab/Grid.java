
package CALab;

import java.awt.*;
import java.util.*;
import java.io.*;
import mvc.*;

public abstract class Grid extends Model {
    static private int time = 0;
    protected int dim = 20;
    protected Cell[][] cells;

    public int getDim() { return dim; }
    public int getTime() { return time; }
    public Cell getCell(int row, int col) { return cells[row][col]; }
    public void setCells(int row, int col, Cell val){
        cells[row][col] = val;
    }
    public abstract Cell makeCell(boolean uniform);
    public Grid(int dim) {
        this.dim = dim;
        cells = new Cell[dim][dim];
        populate();
    }
    public Grid() { this(20); }
    protected void populate() {
        //makeCell(true);
        for (int row = 0; row < dim; row++) {
            for (int col = 0; col < dim; col++) {
                Cell cell = makeCell(true);
                cell.row = row;
                cell.col = col;
                cells[row][col] = cell;
            }
        }

        for (Cell[] row: cells) {
            for (Cell cell : row) {
                cell.neighbors = getNeighbors(cell, 1);
            }
        }
        // 1. use makeCell to fill in cells
        // 2. use getNeighbors to set the neighbors field of each cell
    }

    // called when Populate button is clicked
    public void repopulate(boolean randomly) {
        //System.out.println("Im in repopulate. The boolean is this: " + randomly);
        if (randomly) {
            for(int i = 0; i< cells.length; i++){
                for(int j=0; j < cells[i].length; j++){
                    //random number generator from 0 to 1
                    //whatever number is landed --> change status & change color
                    //so this = running 400 times (one for each cell)
                    cells[i][j].reset(true);
                    //System.out.println("Fuck me. The boolean is this: " + randomly);
                    //cells[i][j].update();
                }
            }
            // randomly set the status of each cell
        } else {
            for(int i = 0; i< cells.length; i++){
                for(int j=0; j < cells[i].length; j++){
                    cells[i][j].reset(false);
                }
            }
            // set the status of each cell to 0 (dead)
        }
        observe();
        notifySubscribers();
        time = 0;
        // notify subscribers
    }


    public Set<Cell> getNeighbors(Cell asker, int radius) {
        Set<Cell> neighbor = new HashSet<>();
        /*
        return the set of all cells that can be reached from the asker in radius steps.
        If radius = 1 this is just the 8 cells touching the asker.
        Tricky part: cells in row/col 0 or dim - 1.
        The asker is not a neighbor of itself.
        */

        int currRow = (asker.row - radius + dim) % dim;
        int startCol = (asker.col - radius + dim) % dim;
        int currCol = startCol;

        while (currRow != (asker.row + radius + 1) % dim) {
            while (currCol != (asker.col + radius + 1) % dim) {
                if (currRow != asker.row || currCol != asker.col) {
                    neighbor.add(cells[currRow][currCol]);
                }
                currCol = (currCol + 1) % dim;
            }
            currCol = startCol;
            currRow = (currRow + 1) % dim;
        }

        return neighbor;
        //returns the neighbor set
    }

    // overide these
    public Color getColor() { return Color.GREEN; } // should this be in cell class or grid class
    //replace getColor() here if it smn goes wrong

    // cell phases:

    public void observe() {
        for(int i = 0; i< cells.length; i++){
            for(int j=0; j < cells[i].length; j++){
                (getCell(i,j)).observe();
                notifySubscribers();
            }
        }
        // call each cell's observe method and notify subscribers
    }

    public void interact() {
        for(int i = 0; i< cells.length; i++){
            for(int j=0; j < cells[i].length; j++){
                (getCell(i,j)).interact();
            }
        }
    }

    public void update() {
        for(int i = 0; i< cells.length; i++){
            for(int j=0; j < cells[i].length; j++){
                (getCell(i,j)).update();
            }
        }
        notifySubscribers();
    }

    public void updateLoop(int cycles) {
        observe();
        for(int cycle = 0; cycle < cycles; cycle++) {
            interact();
            update();
            observe();
            time++;
            System.out.println("time = " + time);
        }
    }

}


