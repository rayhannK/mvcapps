package CALab;

import javax.swing.*;

import mvc.*;
import java.awt.*;

public class GridView  extends View {

    private CellView cellViews[][];

    public GridView(Model model) {
        super(model);
        Grid g = (Grid)model;
        cellViews = new CellView[g.dim][g.dim];
        for(int i = 0; i<g.dim; i++){
            for(int j = 0; j<g.dim; j++){
                cellViews[i][j] = new CellView(g.getCell(i,j));
                setLayout(new GridLayout(((Grid) model).getDim(), ((Grid) model).getDim()));
                cellViews[i][j].update();
                add(cellViews[i][j]);
            }
        }
        //set cell.row and cell.col here

    }

    private void setCellViews() {
        removeAll();
        int dim = ((Grid) model).getDim();

        setLayout(new GridLayout(dim, dim));
        cellViews = new CellView[dim][dim];

        for (int row = 0; row < dim; row++) {
            for (int col = 0; col < dim; col++) {
                cellViews[row][col] = new CellView(((Grid) model).getCell(row, col));
                add(cellViews[row][col]);
            }
        }
        update();
    }

    public void setModel(Model model) {
        super.setModel(model);
        setCellViews();
    }

    public void update() {
        for(int i = 0; i< cellViews.length; i++){
            for(int j=0; j < cellViews[i].length; j++){
                cellViews[i][j].update();
            }
        }
        // call update method of each CellView
    }

}

