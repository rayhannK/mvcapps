package CALab;
import mvc.*;


public abstract class GridFactory implements AppFactory{

    public String[] getEditCommands() { return new String[] {"RUN1", "RUN50", "POPULATE", "CLEAR"}; }

    // source added 3/15 to support text fields
    public Command makeEditCommand(Model model, String type, Object source) {
        if (type == "RUN1")
            return new Run1Command(model);
        if (type == "RUN50")
            return new Run50Command(model);
        if (type == "POPULATE")
            return new PopulateCommand(model);
        if (type == "CLEAR")
            return new ClearCommand(model);
        return null;
    }
    public String[] getHelp() {
        return new String[] {"click Change to cycle through colors"};
    }
    public View makeView(Model m) {
        return new GridView((Grid)m);
    }


}
