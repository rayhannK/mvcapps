package mvc;

public interface CommandInt {
    void execute();
    void undo();
}
