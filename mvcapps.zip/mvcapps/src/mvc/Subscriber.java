package mvc;

public interface Subscriber {
    public void update();
}
