package life;

import CALab.Cell;
import mvc.Utilities;

import java.awt.*;
import java.util.Random;

public class Agent extends Cell {

    //what are we supposed to do with all these override methods?
    //because we = needing to override these methods to extend Cell class
    int ambience = 0;
    int state = 0; // alive or dead
    public void update(){
        //if cell = dead --> do we want it to stay dead or do we want it to be alive?
            //we determine this by checking its ambience & the conditions
        //if cell = alive --> do we want it to stay alive or do we want it to be dead?
            //we do same thing as above
        // update the state
        if (state == 0) {
            if (ambience == 2 || ambience == 3) {
                state = 1;
            }
            else {
                state = 0;
            }
        }
        else {
            if (ambience < 2 || ambience > 3) {
                state = 0;
            }
            else {
                state = 1;
            }
        }
    }

    @Override
    public void nextState() {
        //setting the state to its opposite when u click on it
        if (state == 0) {
            state = 1;
        }
        else {
            state = 0;
        }
    }

    @Override
    public void reset(boolean randomly) {
        //if randomly --> sets every cell to random 0 or 1
        //if not --> everything is set to zero (everything's dead)
        if (randomly) {
            //Random stuff = Utilities.rng;
            //how to use the above statement...?

            int randomNum = (int)(Math.random() * ((1) + 1));
            state = randomNum;

        }
        else {
            state = 0;
            //it says in cell class that it's setting state to random or initial value (0)
        }
    }

    @Override
    public int getStatus() {
        return ambience;
    }
    //change it to ambience if smn = not working (bc that's what prof did)

//    public int getAmbience() {
//        observe();
//        return ambience;
//    }

    @Override
    public Color getColor() {
        if (state == 0) {
            return Color.RED;
        }
        else {
            return Color.GREEN;
        }
    }
    //if dead --> color red
    //if alive --> color green

    public void observe(){
        // update the ambiance
        //loop thru neighbors set in cell
        // get counter 4 that --> make ambience equal that

        int count = 0;
        for (Cell cell : neighbors) {
            if (((Agent)cell).state == 1) {
                count++;
            }
        }
        ambience = count;

    }

    @Override
    public void interact() {
        //just do nothing on this part
        //this = should be here for voting patterns lab
    }

}
