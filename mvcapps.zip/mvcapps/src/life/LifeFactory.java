package life;

import CALab.GridFactory;
import mvc.Model;

public class LifeFactory extends GridFactory {
    public Model makeModel() { return new Society(); }

    public String getTitle() { return "CA Lab"; }

    public String about() {
        return "CA Lab version 1.0. Copyright 2024 by MSR";
    }

    public static void main(String[] args) {
        LifeFactory life = new LifeFactory();
    }
}
