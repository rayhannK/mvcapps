package SimStation;

import mvc.Model;

import java.util.*;

public class Simulation extends Model {
    public int clock = 0;
    transient private Timer timer;



    private void timer() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new ClockUpdater(), 1000, 1000);
    }

    private void stopTimer() {
        timer.cancel();
        timer.purge();
    }

    private class ClockUpdater extends TimerTask {

        @Override
        public void run() {
            clock++;
        }
    }

}
