package SimStation;

public class AgentState {
}
