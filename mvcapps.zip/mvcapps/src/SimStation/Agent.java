package SimStation;

import java.io.Serializable;

public abstract class Agent implements Runnable, Serializable {

}
