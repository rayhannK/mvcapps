package SimStation;

import CALab.*;
import mvc.AppFactory;
import mvc.Command;
import mvc.Model;
import mvc.View;

public abstract class SimulationFactory implements AppFactory {
    public String[] getEditCommands() { return new String[] {"START", "SUSPEND", "RESUME", "STOP", "STATS"}; }

    // source added 3/15 to support text fields
    public Command makeEditCommand(Model model, String type, Object source) {
        if (type == "START")
            return new StartCommand(model);
        if (type == "SUSPEND")
            return new SuspendCommand(model);
        if (type == "RESUME")
            return new ResumeCommand(model);
        if (type == "STOP")
            return new StopCommand(model);
        if (type == "STATS")
            return new StatsCommand(model);
        return null;
    }
    public String[] getHelp() {
        return new String[] {
                "Start: Starts the simulation",
                "Suspend: Stops the simulation",
                "Resume: Resumes the simulation, considering it was stopped",
                "Stop: Stops the simulation",
                "Stats: Provides the statistics of the simulation"
        };
    }
    public View makeView(Model m) {
        return new SimulationView((Simulation)m);
    }
}
